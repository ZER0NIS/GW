#include "stdafx.h"

#include "BaseManager.h"

#include "../World.h"

CBaseManager::CBaseManager()
{
}

CBaseManager::CBaseManager(CWorld* pWorld) :m_pWorld(pWorld)
{
}

CBaseManager::~CBaseManager()
{
}