#include "stdafx.h"
#include "QuestDef.h"