#include "stdafx.h"
#include "Obj.h"

IObj::IObj() :m_GMctr(new GMCrl())
{
}

IObj::~IObj()
{
}