#pragma once

class CCountry
{
public:
	CCountry(void);
public:
	~CCountry(void);
};
