#include "StdAfx.h"
#include "Country.h"

CCountry::CCountry(void)
{
}

CCountry::~CCountry(void)
{
}