#include "..\Inc\ThreadPool.h"

namespace sbase
{
	//MYHEAP_IMPLEMENTATION(ITask, s_heap);
	ITask::~ITask()
	{
	}
}