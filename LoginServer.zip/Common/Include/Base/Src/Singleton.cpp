#include "..\inc\Singleton.h"

namespace sbase
{
	//   template<typename T>
	   //T& Singleton<T>::Instance()
	   //{
	   //	if ( NULL == S_instance )
	   //	{
	   //		S_instance = new T;
	   //	}

	   //	return *S_instance;
	   //}
}