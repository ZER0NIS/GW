#pragma once

namespace sbase
{
	namespace thread
	{
		class Mutex
		{
		public:
			Mutex(void);
		public:
			~Mutex(void);
		};
	}
}
