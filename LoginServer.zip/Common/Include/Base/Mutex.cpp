#include "Mutex.h"

namespace sbase
{
	namespace thread
	{
		Mutex::Mutex(void)
		{
		}

		Mutex::~Mutex(void)
		{
		}
	}
}